from email.policy import default
from enum import unique
from operator import mod
from optparse import Option
from re import M
from xmlrpc.client import DateTime
from django.db import models
import uuid
from datetime import datetime

class cl_New_organization(models.Model):
    """Models which creates table for New Organization"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_code = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=50,null=True)
    ch_parent = models.CharField(max_length=100,null=True)
    ch_delivery_model = models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_New_organization'


class cl_Team(models.Model):
    """Models Which create a table for team"""
    id = models.AutoField(primary_key=True)
    ch_teamname = models.CharField(max_length=100, null=True)
    ch_teamstatus = models.CharField(max_length=100,null=True)
    # ch_organization = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete = models.CASCADE ,null=True)
    e_team_emailfield = models.EmailField(null = True)
    i_team_phonenumber = models.CharField(max_length=200,null=True)
    b_team_notification = models.CharField(max_length=100,null=True)
    ch_team_function = models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.ch_teamname
    class Meta:
        db_table='cl_Team'


class cl_Person(models.Model):
    """Models which create table for Person Information"""
    ch_person_firstname = models.CharField(max_length=100,null=True)
    ch_person_lastname = models.CharField(max_length=100, null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE ,null = True)
    ch_person_status = models.CharField(max_length=100,null=True)
    ch_person_location = models.CharField(max_length=100,null=True)
    ch_person_function = models.CharField(max_length=100, null=True)
    ch_manager = models.CharField(max_length=100,null=True)
    ch_employee_number = models.CharField(max_length=100, null=True)
    e_person_email = models.EmailField(null = True)
    ch_person_phone = models.CharField(max_length=100,null=True)
    ch_person_mobilenumber = models.CharField(max_length=200,null=True)

    def __str__(self):
        return self.ch_person_firstname
    class Meta:
        db_table='cl_Person'


class cl_Location(models.Model):
    """This model create table for details of location"""
    ch_location_name = models.CharField(max_length=100,null=True)
    txt_address = models.TextField(null=True)
    ch_owner_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE,null=True)
    ch_city = models.CharField(max_length=100,null=True)
    i_pincode = models.IntegerField()
    ch_country = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=100, default='active')

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Location'


class cl_Document(models.Model):
    """This model creates table for to insert information about documentation """
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_version = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()
    """ Create here Disable Document type  """
    txt_text= models.TextField()
    url_URL=models.URLField()
    ch_File=models.CharField(max_length=100,null=True)


    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Document'


class cl_Software(models.Model):
    """This models creates table for Software"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_vendor = models.CharField(max_length=100,null=True)
    chversion = models.CharField(max_length=100,null=True)
    ch_type = models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Software'


class cl_Application_solution(models.Model):
    """Models which create table for Application Solution"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    dt_move_to_production_date = models.DateField(default=datetime.now)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Application_solution'




class cl_Delivery_model(models.Model):
    """Models which create table for Delivery Model"""
    ch_application_name = models.CharField(max_length=50,null=True)
    ch_oranization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Delivery_model'


class cl_Business_process(models.Model):
    """Models which creates table for Business Process"""
    ch_business_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_status = models.CharField(max_length=50,null=True)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    dt_move_to_production_date = models.DateField(default=datetime.now)
    txt_description = models.TextField()

    def __str__(self):
        return self.name

    class Meta:
        db_table='cl_Business_process'





class cl_Delivery_model(models.Model):
    ch_name=models.CharField(max_length=50,null=True)
    ch_organization=models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_description=models.TextField()
  
    def __str__(self):
        return self.name

    class Meta:
        db_table='cl_Delivery_model'



class cl_Business_process(models.Model):
    ch_name=models.CharField(max_length=100,null=True)
    ch_organization=models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_status=models.CharField(max_length=50,null=True)
    ch_business_criticality=models.CharField(max_length=100,null=True)
    ch_move_to_production_date=models.DateField(default=datetime.now)
    ch_description=models.TextField()
   
    def __str__(self):
        return self.name

    class Meta:
        db_table='cl_Business_process'


class cl_Newdb_server(models.Model):
    """ Models which creates table for New db Server"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_status = models.CharField(max_length=50,null=True)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    dt_move_to_production_date = models.DateField(default=datetime.now)
    ch_software = models.CharField(max_length=100,null=True)
    ch_software_license = models.CharField(max_length=100,null=True)
    ch_system = models.CharField(max_length=100,null=True)
    ch_path = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Newdb_server'


class cl_Database_schema(models.Model):
    """Models which create the table for Database Schema """
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_db_server = models.CharField(max_length=100,null=True)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    dt_move_to_production_date = models.DateField(default=datetime.now)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Database_schema'


class cl_New_middleware(models.Model):
    """Models which create the table for New Middleware"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_status = models.CharField(max_length=50,null=True)
    ch_system = models.CharField(max_length=100,null=True)
    ch_software = models.CharField(max_length=100,null=True)
    ch_software_license = models.CharField(max_length=100,null=True)
    ch_path = models.CharField(max_length=100,null=True)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    dt_move_to_production_date = models.DateField(default=datetime.now)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_New_middleware'


class cl_Middleware_instance(models.Model):
    """Models which creates the table for Middleware Instance """
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_middleware = models.CharField(max_length=100,null=True)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    dt_move_to_production_date = models.DateField(default=datetime.now)
    txt_description = models.TextField()
    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Middleware_instance'


class cl_Network_device(models.Model):
    """Models which create table for Network Device"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_status = models.CharField(max_length=100,null=True)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    ch_location = models.CharField(max_length=100,null=True)
    ch_network_type = models.CharField(max_length=100,null=True)
    ch_brand = models.CharField(max_length=100,null=True)
    ch_model = models.CharField(max_length=100,null=True)
    i_ios_version = models.IntegerField()
    i_management_ip = models.IntegerField()
    ch_ram = models.CharField(max_length=100,null=True)
    i_rack_unit = models.IntegerField()
    i_serial_number = models.IntegerField()
    i_asset_number = models.IntegerField()
    dt_move_to_production_date = models.DateField(default=datetime.now)
    dt_purchase_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    dt_end_of_warranty = models.DateField(default=datetime)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Network_device'
        

class cl_Other_software(models.Model):
    """Modles which create the table for Other Software"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_status = models.CharField(max_length=100,null=True)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    ch_system = models.CharField(max_length=100,null=True)
    ch_path = models.CharField(max_length=100,null=True)
    ch_software = models.CharField(max_length=100,null=True)
    ch_software_license = models.CharField(max_length=100,null=True)
    dt_move_to_production_date = models.DateField(default=datetime.now)
    txt_description = models.TextField()
    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Other_software'



class cl_Web_application(models.Model):
    """Models which create the table for Web Application """
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_webserver  = models.CharField(max_length=100,null=True)
    url_website = models.URLField(max_length=200)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    move_to_production_date = models.DateField(default=datetime.now)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Web_application'


class cl_Web_server(models.Model):
    """Models which create the table for Web Server"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_status = models.CharField(max_length=100,null=True)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    ch_system = models.CharField(max_length=100,null=True)
    ch_path = models.CharField(max_length=100,null=True)
    ch_software = models.CharField(max_length=100,null=True)
    ch_software_license = models.CharField(max_length=100,null=True)
    dt_move_to_production_date = models.DateField(default=datetime.now)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Web_server'


class cl_Server(models.Model):
    """ Models which create the table for Server"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_status = models.CharField(max_length=100,null=True)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    ch_location = models.CharField(max_length=100,null=True)
    ch_os_family = models.CharField(max_length=100,null=True)
    ch_brand = models.CharField(max_length=100,null=True)
    ch_model = models.CharField(max_length=100,null=True)
    i_os_version = models.IntegerField()
    i_management_ip = models.IntegerField()
    i_os_license = models.IntegerField()
    ch_ram = models.CharField(max_length=100,null=True)
    ch_cpu = models.CharField(max_length=100,null=True)
    i_rack_unit = models.IntegerField()
    i_serial_number = models.IntegerField()
    i_asset_number = models.IntegerField()
    dt_move_to_production_date = models.DateField(default=datetime.now)
    dt_purchase_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    dt_end_of_warranty = models.DateTimeField(auto_now=False, auto_now_add=False)

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Server'



class cl_Pc_software(models.Model):
    """Models Which create the table for PC Software """
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization =models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_status = models.CharField(max_length=100,null=True)
    ch_business_criticality = models.CharField(max_length=100,null=True)
    ch_system = models.CharField(max_length=100,null=True)
    ch_path = models.CharField(max_length=100,null=True)
    ch_software = models.CharField(max_length=100,null=True)
    ch_software_license = models.CharField(max_length=100,null=True)
    ch_path = models.CharField(max_length=100,null=True)
    dt_move_to_production_date = models.DateField(default=datetime.now)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Pc_software'


class cl_User_request(models.Model):
    """Models which create the table for User Request"""
    fk_organization = models.ForeignKey(cl_New_organization,on_delete=models.CASCADE)
    fk_caller = models.ForeignKey(cl_Person,on_delete=models.CASCADE)
    ch_status = models.CharField(max_length=100, default='active')
    ch_origin = models.CharField(max_length=100,null=True)
    ch_title = models.CharField(max_length=100,null=True)
    ch_request_type = models.CharField(max_length=100,null=True)
    ch_impact = models.CharField(max_length=100,null=True)
    ch_urgency = models.CharField(max_length=100,null=True)
    ch_priority = models.CharField(max_length=100,null=True)
    dt_start_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    dt_end_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    ch_service = models.CharField(max_length=100,null=True)
    ch_service_subcategory = models.CharField(max_length=100,null=True)
    ch_parent_request = models.CharField(max_length=100,null=True)
    ch_parent_change = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_User_request'


class cl_New_change(models.Model):
    """Models which create the table for New Change"""
    ch_organization = models.ForeignKey(cl_New_organization ,on_delete=models.CASCADE)
    ch_caller = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=100, default='new')
    ch_category = models.CharField(max_length=100,null=True)
    ch_title = models.CharField(max_length=100,null=True)
    dt_start_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    dt_end_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    ch_parent_change = models.CharField(max_length=100,null=True)
    txt_fallback_plan = models.TextField()
    txt_description = models.TextField()

    def __str__(self):
        return self.ch_organization
    class Meta:
        db_table='cl_New_change'





class cl_Customer_contract(models.Model):
    """Models which create the table for User Request"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_customer = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=100, default='new')
    ch_contract_type = models.CharField(max_length=100,null=True)
    ch_provider = models.CharField(max_length=100,null=True)
    dt_start_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    dt_end_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    i_cost_unit=models.IntegerField()
    i_cost=models.IntegerField()
    i_cost_currency=models.IntegerField()
    i_billing_frequency=models.IntegerField()
    txt_description=models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Customer_contract'


class cl_Providercontract(models.Model):
    """Models which create the table for Provider Contract"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_customer = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=100, default='new')
    ch_contract_type = models.CharField(max_length=100,null=True)
    ch_provider = models.CharField(max_length=100,null=True)
    dt_start_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    dt_end_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    i_cost_unit = models.IntegerField()
    i_cost = models.IntegerField()
    i_cost_currency = models.IntegerField()
    i_billing_frequency = models.IntegerField()
    txt_description = models.TextField()
    ch_sla = models.CharField(max_length=100,null=True)
    f_service_hours = models.FloatField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Providercontract'


class cl_Servicefamilies(models.Model):
    """Models which create the table for Provider Contract"""
    ch_name = models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Servicefamilies'


class cl_Service(models.Model):
    """Models which create the table for Provider Contract"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_provider = models.CharField(max_length=100,null=True)
    ch_service_family = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Service'



class cl_Service_subcategory(models.Model):
    """Models which create the table for Provider Contract"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_service = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=100,null=True)
    ch_request_type = models.CharField(max_length=100,null=True)
    ch_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Service_subcategory'

class cl_Sla(models.Model):
    """Models which create the table for Provider Contract"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_provider = models.CharField(max_length=100,null=True)
    ch_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Sla'


class cl_Slt(models.Model):
    """Models which create the table for SLT"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_priority = models.CharField(max_length=100,null=True)
    ch_request_type = models.CharField(max_length=100,null=True)
    ch_metric = models.CharField(max_length=100,null=True)
    ch_value = models.CharField(max_length=100,null=True)
    ch_unit = models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Slt'


class cl_Servicedelivery(models.Model):
    """Models which create the table for Service Delivery"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_organization = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Servicedelivery'


class cl_Synchro_data_source(models.Model):
    """Models which create the table for Synchro Data Source"""
    ch_name = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=100, default='implementation')
    txt_description = models.TextField()
    ch_target_class = models.CharField(max_length=100,null=True)
    ch_user = models.CharField(max_length=100,null=True)
    ch_contact_notify = models.CharField(max_length=100,null=True)
    url_icon_hyperlink = models.URLField(max_length=200)
    url_Application_hyperlink = models.URLField(max_length=200)
    ch_data_table = models.CharField(max_length=100,null=True)
    ch_reconciliation_policy = models.CharField(max_length=100,null=True)
    ch_action_on_zero = models.CharField(max_length=100,null=True)
    ch_action_on_one = models.CharField(max_length=100,null=True)
    ch_action_on_many = models.CharField(max_length=100,null=True)
    ch_users_allowed = models.CharField(max_length=100,null=True)
    ch_update_rules = models.CharField(max_length=100,null=True)
    ch_delete_policy = models.CharField(max_length=100,null=True)
    dt_full_load_interval = models.DateTimeField(auto_now=False, auto_now_add=False)
    dt_retention_duration = models.DateTimeField(auto_now=False, auto_now_add=False)

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Synchro_data_source'

class cl_Oauth_google(models.Model):
    """Models which create the table for Oauth Google"""
    e_login=models.EmailField()
    ch_status=models.CharField(max_length=100,default='No Acess token')
    ch_provider=models.CharField(max_length=100,default='Google')
    txt_description=models.TextField()
    ch_client_id=models.CharField(max_length=100,null=True)
    ch_client_secret=models.CharField(max_length=100,null=True)
    ch_scope=models.CharField(max_length=100,default='SMTP')
    ch_advanced_scope=models.CharField(max_length=100,null=True)
    ch_used_smtp=models.CharField(max_length=100,null=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Oauth_google'

class cl_Oauth_mazure(models.Model):
    """Models which create the table for Oauth Google"""
    e_login = models.EmailField()
    ch_status = models.CharField(max_length=100,default='No Acess token')
    ch_provider = models.CharField(max_length=100,default='Azure')
    txt_description = models.TextField()
    ch_client_id = models.CharField(max_length=100,null=True)
    ch_client_secret = models.CharField(max_length=100,null=True)
    ch_scope = models.CharField(max_length=100,default='SMTP')
    ch_advanced_scope = models.CharField(max_length=100,null=True)
    ch_used_smtp = models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Oauth_mazure'


class cl_Ldapuser(models.Model):
    ch_person = models.CharField(max_length=100,null=True)
    ch_ldapserver = models.CharField(max_length=100,null=True)
    e_email = models.EmailField()
    ch_login = models.CharField(max_length=100,null=True)
    ch_language = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Ldapuser'



class cl_Externaluser(models.Model):
    """Models which create the table for External User"""
    ch_person = models.CharField(max_length=100,null=True)
    ch_first_name = models.CharField(max_length=100,null=True)
    e_email = models.EmailField()
    ch_login = models.CharField(max_length=100,null=True)
    ch_language = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=100,null=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Externaluser'


class ch_Itsmuser(models.Model):
    """Models which create the table for Itsmuser """
    ch_person = models.CharField(max_length=100,null=True)
    ch_email = models.EmailField()
    ch_login = models.CharField(max_length=100,null=True)
    ch_language = models.CharField(max_length=100,null=True)
    ch_status = models.CharField(max_length=100,null=True)
    ch_person = models.CharField(max_length=100,null=True)
    ch_password = models.CharField(max_length=100,null=True)
    ch_password_expiration = models.CharField(max_length=100,null=True)
    dt_password_renewed_on = models.DateTimeField(auto_now=False, auto_now_add=False)
    def __str__(self):
        return self.name
    class Meta:
        db_table='ch_Itsmuser'


class cl_Slacknotification(models.Model):
    """Models which create the table for Slacknotification"""
    ch_name = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()
    ch_status = models.CharField(max_length=100, default='Inactive')
    ch_language = models.CharField(max_length=100, default='English')
    ch_Connection = models.CharField(max_length=100,null=True)
    ch_testconnection = models.CharField(max_length=100,null=True)
    txt_message = models.TextField()
    ch_Attributes_forms = models.CharField(max_length=100,null=True)
    ch_modify_button = models.CharField(max_length=100,null=True)
    b_delete_button = models.BooleanField()
    b_other_action = models.BooleanField()
    ch_other_action_code = models.CharField(max_length=100,null=True)
    b_user_info = models.BooleanField()
    ch_Prepare_payload_callback = models.CharField(max_length=100,null=True)
    ch_Process_response_callback = models.CharField(max_length=100,null=True)
    b_other_action = models.BooleanField()
    ch_other_action_code = models.CharField(max_length=100,null=True)
    b_user_info = models.BooleanField()

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Slacknotification'


class cl_Microsoft_Teams_notification(models.Model):
    """Models which create the table for Microsoft_Teams_notification"""
    ch_name = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()
    ch_status = models.CharField(max_length=100, default='Inactive')
    ch_language = models.CharField(max_length=100, default='English')
    ch_Connection = models.CharField(max_length=100,null=True)
    ch_testconnection = models.CharField(max_length=100,null=True)
    txt_message = models.TextField()
    ch_Attributes_forms = models.CharField(max_length=100,null=True)
    ch_modify_button = models.CharField(max_length=100,null=True)
    b_delete_button = models.BooleanField()
    ch_Prepare_payload_callback = models.CharField(max_length=100,null=True)
    ch_Process_response_callback = models.CharField(max_length=100,null=True)
    b_other_action = models.BooleanField()
    ch_other_action_code = models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Microsoft_Teams_notification'


class cl_Webhook(models.Model):
    """Models which create the table for WebHook"""
    ch_name = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()
    ch_status = models.CharField(max_length=100, default='Inactive')
    ch_language = models.CharField(max_length=100, default='English')
    ch_Connection = models.CharField(max_length=100,null=True)
    ch_testconnection = models.CharField(max_length=100,null=True)
    txt_message = models.TextField()
    ch_method = models.CharField(max_length=100,null=True)
    ch_headers = models.CharField(max_length=100,null=True)
    ch_payload = models.CharField(max_length=100,null=True)
    b_delete_button = models.BooleanField()
    ch_Prepare_payload_callback = models.CharField(max_length=100,null=True)
    ch_Process_response_callback = models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Webhook'


class cl_Googlechat(models.Model):
    """Models which create the table for GoogleChat"""
    ch_name = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()
    ch_status = models.CharField(max_length=100, default='Inactive')
    ch_language = models.CharField(max_length=100, default='English')
    ch_Connection = models.CharField(max_length=100,null=True)
    ch_testconnection = models.CharField(max_length=100,null=True)
    txt_message = models.TextField()
    ch_Prepare_payload_callback = models.CharField(max_length=100,null=True)
    ch_Process_response_callback = models.CharField(max_length=100,null=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Googlechat'


class cl_Rocketchat(models.Model):
    """Models which create the table for Rocketchat"""
    ch_name = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()
    ch_status = models.CharField(max_length=100, default='Inactive')
    ch_language = models.CharField(max_length=100, default='English')
    ch_Connection = models.CharField(max_length=100,null=True)
    ch_testconnection = models.CharField(max_length=100,null=True)
    txt_message = models.TextField()
    ch_Prepare_payload_callback = models.CharField(max_length=100,null=True)
    ch_Process_response_callback = models.CharField(max_length=100,null=True)
    ch_Alias = models.CharField(max_length=100,null=True)
    ch_Image_avtar = models.CharField(max_length=100,null=True)
    Emoji_avtar=models.CharField(max_length=100,null=True)
    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Rocketchat'


class cl_Itsmwebhook(models.Model):
    """Models which create the table for Itsmwebhook"""
    ch_name = models.CharField(max_length=100,null=True)
    txt_description = models.TextField()
    ch_status = models.CharField(max_length=100, default='Inactive')
    ch_language = models.CharField(max_length=100, default='English')
    ch_Connection = models.CharField(max_length=100,null=True)
    ch_testconnection = models.CharField(max_length=100,null=True)
    txt_headers = models.TextField()
    txt_json_data = models.TextField()
    Prepare_payload_callback=models.CharField(max_length=100,null=True)
    Process_response_callback=models.CharField(max_length=100,null=True)
    
    def __str__(self):
        return self.name
    class Meta:
        db_table='cl_Itsmwebhook'