from tool.forms import *
from django.shortcuts import render, redirect
from django.contrib import messages
from tool.models import cl_Person,cl_Location,cl_Team




def configuration(request):
    return render(request,'tool/configurationmanagement.html')

def contact(request):
    return render(request,'tool/contact.html')


# def client(request):
#     per=cl_Person.objects.all()

#     context={
#         'per':per,
#     }
#     return render(request,'tool/client.html',context)
    
# # For Person
# def ADD(request):
#     if request.method == "POST":
#         firstname=request.POST.get('firstname')
#         lastname=request.POST.get('lastname')
#         organisation=request.POST.get('organisation')
#         status=request.POST.get('status')
#         location=request.POST.get('location')
#         function=request.POST.get('function')
#         manager=request.POST.get('manager')
#         employee_number=request.POST.get('employee_number')
#         email=request.POST.get('email')
#         phone=request.POST.get('phone')
#         mobilenumber=request.POST.get('mobilenumber')
#         per=cl_Person(
#             firstname = firstname,
#             lastname = lastname,
#             organisation = organisation,
#             status = status,
#             location = location,
#             function = function,
#             manager = manager,
#             employee_number = employee_number,
#             email = email,
#             phone = phone,
#             mobilenumber = mobilenumber,
#         )
#         per.save()
#         return redirect('client')
#     return render(request,'tool/client.html')

# def Edit(request):
#     per = cl_Person.objects.all()
#     context={
#         'per':per,
#     }
#     return render(request,'tool/client.html',context)

# def Update(request,id):
#     if request.method == "POST":
#         firstname=request.POST.get('firstname')
#         lastname=request.POST.get('lastname')
#         organisation=request.POST.get('organisation')
#         status=request.POST.get('status')
#         location=request.POST.get('location')
#         function=request.POST.get('function')
#         manager=request.POST.get('manager')
#         employee_number=request.POST.get('employee_number')
#         email=request.POST.get('email')
#         phone=request.POST.get('phone')
#         mobilenumber=request.POST.get('mobilenumber')
#         per=cl_Person(
#             firstname = firstname,
#             lastname = lastname,
#             organisation = organisation,
#             status = status,
#             location = location,
#             function = function,
#             manager = manager,
#             employee_number = employee_number,
#             email = email,
#             phone = phone,
#             mobilenumber = mobilenumber,
#         )
#         per.save()
#         return redirect('client')
#     return render(request,'tool/client.html')

# def Delete(request,id):
#     per=cl_Person.objects.filter(id=id)
#     per.delete()
#     context={
#         'per':per,
#     }
#     return redirect('client')




# def service(request):
#     tem=cl_Team.objects.all()
    
#     context={
#         'tem':tem,
#     }
    
#     return render(request, 'tool/service.html', context)    


# def TADD(request):
#     if request.method == "POST":
#         id=request.POST.get('id')
#         ch_teamname=request.POST.get('ch_teamname')
#         ch_status=request.POST.get('ch_status')
#         ch_organisation=request.POST.get('ch_organisation')
#         e_team_emailfield=request.POST.get('e_team_emailfield')
#         i_team_phonenumber=request.POST.get('i_team_phonenumber')
#         b_team_notification=request.POST.get('b_team_notification')
#         ch_function=request.POST.get('ch_function')
#         tem=cl_Team(
#             id = id,
#             ch_teamname = ch_teamname,
#             ch_status = ch_status,
#             ch_organisation = ch_organisation,
#             e_team_emailfield = e_team_emailfield,
#             i_team_phonenumber = i_team_phonenumber,
#             b_team_notification = b_team_notification,
#             ch_function = ch_function,
#         )
#         tem.save()
#         return redirect('service')
#     return render(request,'tool/service.html')

# def TEdit(request):
#     tem = cl_Team.objects.all()
#     context={
#         'tem':tem,
#     }
#     return render(request,'tool/service.html',context)

# def TUpdate(request,id):
#     if request.method == "POST":
#         id=request.POST.get('id')
#         ch_teamname=request.POST.get('ch_teamname')
#         ch_status=request.POST.get('ch_status')
#         ch_organisation=request.POST.get('ch_organisation')
#         e_team_emailfield=request.POST.get('e_team_emailfield')
#         i_team_phonenumber=request.POST.get('i_team_phonenumber')
#         b_team_notification=request.POST.get('b_team_notification')
#         ch_function=request.POST.get('ch_function')
#         tem=cl_Team(
#             id=id,
#             ch_teamname=ch_teamname,
#             ch_status = ch_status,
#             ch_organisation = ch_organisation,
#             e_team_emailfield = e_team_emailfield,
#             i_team_phonenumber = i_team_phonenumber,
#             b_team_notification = b_team_notification,
#             ch_function = ch_function,
#         )
#         tem.save()
#         return redirect('service')
#     return render(request,'tool/service.html')

# def TDelete(request,id):
#     tem=cl_Team.objects.filter(id=id)
#     tem.delete()
#     context={
#         'tem':tem,
#     }
#     return redirect('service')





def newci(request):
    return render(request,'tool/newci.html')


# def Location(request):
#     loc =cl_Location.objects.all()

#     context={
#         'loc':loc,
#     }
#     return render(request, 'tool/location.html', context)



# def ADD(request):
#     if request.method=="POST":
#         name=request.POST.get('name')
#         address=request.POST.get('address')
#         owner_organization=request.POST.get('owner_organization')
#         city=request.POST.get('city')
#         pincode=request.POST.get('pincode')
#         country=request.POST.get('country')
#         status=request.POST.get('status')

#         loc=cl_Location(
#             name=name,
#             address=address,
#             owner_organization=owner_organization,
#             city=city,
#             pincode=pincode,
#             country=country,
#             status=status,
#         )
#         loc.save()
#         return redirect('location')
#     return render(request,'tool/location.html')

# def Edit(request):
#     loc=cl_Location.objects.all()
#     context={
#         'loc':loc,
#     }
#     return render(request,'tool/location.html',context)


# def Update(request,id):
#     if request.method=="POST":
#         name=request.POST.get('name')
#         address=request.POST.get('address')
#         owner_organization=request.POST.get('owner_organization')
#         city=request.POST.get('city')
#         pincode=request.POST.get('pincode')
#         country=request.POST.get('country')
#         status=request.POST.get('status')

#         loc=cl_Location(
#             id=id,
#             name=name,
#             address=address,
#             owner_organization=owner_organization,
#             city=city,
#             pincode=pincode,
#             country=country,
#             status=status,
#         )
#         loc.save()
#         return redirect('location')
#     return redirect(request,'tool/location.html')

# def Delete(request,id):
#     loc=cl_Location.objects.filter(id=id)
#     loc.delete()
#     context={
#         'loc':loc,
#     }
#     return redirect('location')





def document(request):
    form=DocumentForm()
    if request.method=='POST':
        form=DocumentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/document.html',context)


def software(request):
    form=SoftwareForm()
    if request.method=='POST':
        form=SoftwareForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/software.html',context)    



def application_solution(request):
    form=ApplicationsolutionForm()
    if request.method=='POST':
        form=ApplicationsolutionForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/application_solution.html',context)

def new_organization(request):
    form=NeworganizationForm()
    
    if request.method=='POST':
        form=NeworganizationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/neworganization.html', context)


def delivery_model(request):
    form=DeliverymodelForm()
    if request.method=='POST':
        form=DeliverymodelForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/delivery_model.html',context)


def business_process(request):
    form=BusinessprocessForm()
    if request.method=='POST':
        form=BusinessprocessForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/business_process.html',context)


def newdb_server(request):
    form=NewdbserverForm()
    if request.method=='POST':
        form=NewdbserverForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/newdb_server.html',context)    

def database_schema(request):
    form=DatabaseschemaForm()
    if request.method=='POST':
        form=DatabaseschemaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/database_schema.html',context)


def new_middleware(request):
    form=NewmiddlewareForm()
    
    if request.method=='POST':
        form=NewmiddlewareForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/new_middleware.html', context)


def middleware_instance(request):
    form=MiddlewareinstanceForm()
    if request.method=='POST':
        form=MiddlewareinstanceForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/middleware_instance.html',context)


def network_device(request):
    form=NetworkForm()
    if request.method=='POST':
        form=NetworkForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/network_device.html',context)


def other_software(request):
    form=OthersoftwareForm()
    if request.method=='POST':
        form=OthersoftwareForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/othersoftware.html',context)    

def web_application(request):
    form=WebapplicationForm()
    if request.method=='POST':
        form=WebapplicationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/webapplication.html',context)

def web_server(request):
    form=WebserverForm()
    if request.method=='POST':
        form=WebserverForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/webserver.html',context)

def network_device(request):
    form=NetworkdeviceForm()
    if request.method=='POST':
        form=NetworkdeviceForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/network_device.html',context)


def server(request):
    form=ServerForm()
    if request.method=='POST':
        form=ServerForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/server.html',context)


def pc_software(request):
    form=PcsoftwareForm()
    if request.method=='POST':
        form=PcsoftwareForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/pc_software.html',context)