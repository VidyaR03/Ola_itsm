from django.urls import path
from . import views
urlpatterns = [
    path('', views.home, name='home'),
    path("register/", views.registerPage, name='register'),
    path('login/', views.loginPage, name='login'),
    path('logout/', views.logoutUser, name='logout'),
    
    #Url for person form
    path('add', views.ADD, name='add'),
    path('edit', views.Edit, name='edit'),
    path('update/<str:id>', views.Update, name='update'),
    path('delete/<str:id>', views.Delete, name='delete'),
    path("client/", views.client,name='client'),

    #Url For Team form
    path('tadd', views.TADD, name='tadd'),
    path('tedit', views.TEdit, name='tedit'),
    path('tupdate/<str:id>', views.TUpdate, name='tupdate'),
    path('tdelete/<str:id>', views.TDelete, name='tdelete'),
    path("team/", views.team, name='team'),

    path("configurationmanagement/", views.configuration, name='configurationmanagement'),
    path("contact/", views.contact, name='contact'),
    path("newci/", views.newci, name='newci'),
   
     
    #Url for Loction form
    path("location/", views.Location,name='location'),
    path('ladd', views.LADD, name='ladd'),
    path('ledit', views.LEdit, name='ledit'),
    path('lupdate/<str:id>', views.LUpdate, name='lupdate'),
    path('ldelete/<str:id>', views.LDelete, name='ldelete'),


    
    # path("organization/", views.add_show,name='neworganization'),







    path("document/", views.document, name='document'),
    path("software/", views.software, name='software'),
    path("application/", views.application_solution, name='application'),
    path("neworganization/", views.new_organization,name='neworganization'),
    path("deliverymodel/", views.delivery_model,name='deliverymodel'),
    path("businessprocess/", views.business_process, name='businessprocess'),
    path("newdb/", views.newdb_server, name='newdb'),
    path("databaseschema/", views.database_schema, name='databaseschema'),
    path("pcsoftware/", views.pc_software, name='pcsoftware'),
    path("server/", views.server, name='server'),
    path("userrequest/", views.user_request, name='userrequest'),
    path("newchange/", views.new_change, name='newchange'),
    path("newmiddleware/", views.new_middleware, name='newmiddleware'),
    path("middlewareinstance/", views.middleware_instance,name='middlewareinstance'),
    path("networkdevice/", views.network_device,name='networkdevice'),
    path("webapplication/", views.web_application, name='webapplication'),
    path("webserver/", views.web_server, name='webserver'),

    #Url for services
    path("servicenav/", views.servicenav, name='servicenav'),
    path("customercontract/", views.customer_contract, name='customercontract'),
    path("providercontract/", views.providercontract,name='providercontract'),
    path("servicefamilies/", views.servicefamilies,name='servicefamilies'),
    path("sservice/", views.sservice, name='service'),
    path("service_subcategory/", views.service_subcategory, name='service_subcategory'),
    path("sla/", views.sla, name='sla'),
    path("slt/", views.slt,name='slt'),

    #url for system configuration
    path("servicedelivery/", views.servicedelivery,name='servicedelivery'),
    path("synchro_data_source/", views.synchro_data_source,name='synchro_data_source'),
    path("sysconfinav/", views.sysconfienav,name='sysconfinav'),
    path("authgoogle/", views.oauth_google,name='authgoogle'),
    path("authmazure/", views.oauth_mazuree,name='authmazure'),
    path("sysconfiauth/", views.sysconfiauth,name='sysconfiauth'),

    #url for administration
    path("admuser/", views.admuser,name='admuser'),
    path("itsmuser/", views.itsmuser,name='itsmuser'),
    path("idapuser/", views.ldapuser,name='idapuser'),
    path("externaluser/", views.externaluser,name='externaluser'),

    #url for integration
    path("integration/", views.integrationav,name='integration'),
    path("slacknoti/", views.slacknoti,name='slacknoti'),
    path("micronoti/", views.micronoti,name='micronoti'),
    path("webhook/", views.webhook,name='webhook'),
    path("googlechat/", views.googlechat,name='googlechat'),
    path("rocketchat/", views.rocketchat,name='rocketchat'),
    path("itsmwebhook/", views.itsmwebhook,name='itsmwebhook'),
   
    ]