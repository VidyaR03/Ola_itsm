from multiprocessing import context
from django.shortcuts import render, redirect
from django.http import HttpResponse
from tool.models import cl_Location
from django.contrib.auth import authenticate, login, logout
import random
import datetime
import time
from django.http import JsonResponse
from tool.models import cl_New_organization
from  django.db.models import Q


# from django.http import HttpResponse, HttpResponseRedirect
# from django.template import loader
# from django.urls import reverse

# from .forms import LocationForm, TeamForm, PersonForm, DocumentForm, SoftwareForm, ApplicationsolutionForm, \
#     NeworganizationForm, DeliverymodelForm,BusinessprocessForm,NewdbserverForm, NeworganizationForm, DeliverymodelForm, \
#         BusinessprocessForm,NewdbserverForm,DatabaseschemaForm,NewmiddlewareForm,MiddlewareinstanceForm,NetworkForm,\
#             OthersoftwareForm,WebapplicationForm,WebserverForm ,NetworkdeviceForm,ServerForm,PcsoftwareForm,UserrequestForm,NewchangeForm,\
#                 CustomercontractForm, ProvidercontractForm, ServicefamiliesForm, ServiceForm, ServicesubcategoryForm, slaForm,\
#                      sltForm, DeliverymodelForm, SyncrodataForm, OauthgoogleForm, OauthmazureeForm, LdapuserForm, ExternaluserForm, ItsmuserForm,\
#                         SlacknotiForm, CreateUserForm, MicronotiForm, WebhookForm, GooglechatForm, RocketchatForm, ItsmwebhookForm 

from .forms import *
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from tool.modules.configurationmanagement.ConfigurationManagement import *


def home(request):
    return render(request,'tool/dashboard.html')



# def configuration(request):
#     return render(request,'tool/configurationmanagement.html')

# def contact(request):
#     return render(request,'tool/contact.html')

# def newci(request):
#     return render(request,'tool/newci.html')

def servicenav(request):
    return render(request,'tool/servicenav.html')

def sysconfienav(request):
    return render(request,'tool/sysconfinav.html')

def sysconfiauth(request):
    return render(request,'tool/sysconfiauth.html')

def admuser(request):
    return render(request,'tool/admuser.html')

def integrationav(request):
    return render(request,'tool/integrationav.html')

def registerPage(request):
    form=CreateUserForm()
    if request.method == 'POST':
        form=CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            user=form.cleaned_data.get('username')
            messages.success(request, 'Account was created for ' +  user )


            return redirect('login')

    context={'form': form}
    return render(request,'tool/register.html',context)

def loginPage(request):

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')

        else:
            messages.info(request, 'Username OR Password is incorrect')
            


    return redirect('login')

def logoutUser(request):
    logout(request)
    return redirect('login')


# def client(request):
#     form=PersonForm()
#     if request.method=='POST':
#         form=PersonForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")

#     context={'form':form}
#     return render(request,'tool/client.html',context)

#def service(request):
 #   return render(request,'tool/service.html') 

# def service(request):
#     form=TeamForm()
    
#     if request.method=='POST':
#         form=TeamForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/service.html', context)



def client (request):
    """
    fetching data using json
    """
    data=list(cl_Person.objects.values())
    return JsonResponse(data,safe=False)





def Location(request):
    loc = cl_Location.objects.all()

    context={
        'loc':loc,
    }
    return render(request, 'tool/location.html', context)

    

def LADD(request):
    if request.method=="POST":
        ch_location_name=request.POST.get('ch_location_name')
        txt_address=request.POST.get('txt_address')
        ch_owner_organization=request.POST.get('ch_owner_organization')
        ch_city=request.POST.get('ch_city')
        i_pincode=request.POST.get('i_pincode')
        ch_country=request.POST.get('ch_country')
        ch_status=request.POST.get('ch_status')

        loc=cl_Location(
            ch_location_name=ch_location_name,
            txt_address=txt_address,
            ch_owner_organization=ch_owner_organization,
            ch_city=ch_city,
            i_pincode=i_pincode,
            ch_country=ch_country,
            ch_status=ch_status,
        )
        loc.save()
        return redirect('location')
    return render(request,'tool/location.html')

def LEdit(request):
    loc=cl_Location.objects.all()
    context={
        'loc':loc,
    }
    return render(request,'tool/location.html',context)


def LUpdate(request,id):
    if request.method=="POST":
        ch_location_name=request.POST.get('ch_location_name')
        txt_address=request.POST.get('txt_address')
        ch_owner_organization=request.POST.get('ch_owner_organization')
        ch_city=request.POST.get('ch_city')
        i_pincode=request.POST.get('i_pincode')
        ch_country=request.POST.get('ch_country')
        ch_status=request.POST.get('ch_status')

        loc=cl_Location(
            id=id,
            ch_location_name=ch_location_name,
            txt_address=txt_address,
            ch_owner_organization=ch_owner_organization,
            ch_city=ch_city,
            i_pincode=i_pincode,
            ch_country=ch_country,
            ch_status=ch_status,
        )
        loc.save()
        return redirect('location')
    return redirect(request,'tool/location.html')

def LDelete(request,id):
    loc=cl_Location.objects.filter(id=id)
    loc.delete()
    context={
        'loc':loc,
    }
    return redirect('location')



# def document(request):
#     form=DocumentForm()
#     if request.method=='POST':
#         form=DocumentForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/document.html',context)


# def software(request):
#     form=SoftwareForm()
#     if request.method=='POST':
#         form=SoftwareForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/software.html',context)    

# def application_solution(request):
#     form=ApplicationsolutionForm()
#     if request.method=='POST':
#         form=ApplicationsolutionForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/application_solution.html',context)

# def new_organization(request):
#     form=NeworganizationForm()
    
#     if request.method=='POST':
#         form=NeworganizationForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/neworganization.html', context)


# def delivery_model(request):
#     form=DeliverymodelForm()
#     if request.method=='POST':
#         form=DeliverymodelForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/delivery_model.html',context)


# def business_process(request):
#     form=BusinessprocessForm()
#     if request.method=='POST':
#         form=BusinessprocessForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/business_process.html',context)


# def newdb_server(request):
#     form=NewdbserverForm()
#     if request.method=='POST':
#         form=NewdbserverForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/newdb_server.html',context)    

# def database_schema(request):
#     form=DatabaseschemaForm()
#     if request.method=='POST':
#         form=DatabaseschemaForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/database_schema.html',context)


# def new_middleware(request):
#     form=NewmiddlewareForm()
    
#     if request.method=='POST':
#         form=NewmiddlewareForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/new_middleware.html', context)


# def middleware_instance(request):
#     form=MiddlewareinstanceForm()
#     if request.method=='POST':
#         form=MiddlewareinstanceForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/middleware_instance.html',context)


# def network_device(request):
#     form=NetworkForm()
#     if request.method=='POST':
#         form=NetworkForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/network_device.html',context)


# def other_software(request):
#     form=OthersoftwareForm()
#     if request.method=='POST':
#         form=OthersoftwareForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/othersoftware.html',context)    

# def web_application(request):
#     form=WebapplicationForm()
#     if request.method=='POST':
#         form=WebapplicationForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/webapplication.html',context)

# def web_server(request):
#     form=WebserverForm()
#     if request.method=='POST':
#         form=WebserverForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/webserver.html',context)

# def network_device(request):
#     form=NetworkdeviceForm()
#     if request.method=='POST':
#         form=NetworkdeviceForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/network_device.html',context)


# def server(request):
#     form=ServerForm()
#     if request.method=='POST':
#         form=ServerForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/server.html',context)


# def pc_software(request):
#     form=PcsoftwareForm()
#     if request.method=='POST':
#         form=PcsoftwareForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,"Data Add Successfully")
#     context={'form':form}
#     return render(request, 'tool/pc_software.html',context)




def client(request):
    per=cl_Person.objects.all()

    context={
        'per':per,
    }
    return render(request,'tool/client.html',context)


# For Person
def ADD(request):
    if request.method == "POST":
        ch_person_firstname =request.POST.get('ch_person_firstname')
        ch_person_lastname=request.POST.get('ch_person_lastname')
        ch_organization=request.POST.get('ch_organization')
        ch_person_status=request.POST.get('ch_person_status')
        ch_person_location=request.POST.get('ch_person_location')
        ch_person_function=request.POST.get('ch_person_function')
        ch_manager=request.POST.get('ch_manager')
        ch_employee_number=request.POST.get('ch_employee_number')
        e_person_email=request.POST.get('e_person_email')
        ch_person_phone=request.POST.get('ch_person_phone')
        ch_person_mobilenumber=request.POST.get('ch_person_mobilenumber')
        per=cl_Person(
            ch_person_firstname = ch_person_firstname,
            ch_person_lastname = ch_person_lastname,
            ch_organization = ch_organization,
            ch_person_status = ch_person_status,
            ch_person_location = ch_person_location,
            ch_person_function = ch_person_function,
            ch_manager = ch_manager,
            ch_employee_number = ch_employee_number,
            e_person_email = e_person_email,
            ch_person_phone = ch_person_phone,
            ch_person_mobilenumber = ch_person_mobilenumber,
        )
        per.save()
        return redirect('client')
    return render(request,'tool/client.html')

def Edit(request):
    per = cl_Person.objects.all()
    context={
        'per':per,
    }
    return render(request,'tool/client.html',context)

def Update(request,id):
    if request.method == "POST":
        ch_person_firstname =request.POST.get('ch_person_firstname')
        ch_person_lastname=request.POST.get('ch_person_lastname')
        ch_organization=request.POST.get('ch_organization')
        ch_person_status=request.POST.get('ch_person_status')
        ch_person_location=request.POST.get('ch_person_location')
        ch_person_function=request.POST.get('ch_person_function')
        ch_manager=request.POST.get('ch_manager')
        ch_employee_number=request.POST.get('ch_employee_number')
        e_person_email=request.POST.get('e_person_email')
        ch_person_phone=request.POST.get('ch_person_phone')
        ch_person_mobilenumber=request.POST.get('ch_person_mobilenumber')

        per=cl_Person(
            ch_person_firstname = ch_person_firstname,
            ch_person_lastname = ch_person_lastname,
            ch_organization = ch_organization,
            ch_person_status = ch_person_status,
            ch_person_location = ch_person_location,
            ch_person_function = ch_person_function,
            ch_manager = ch_manager,
            ch_employee_number = ch_employee_number,
            e_person_email = e_person_email,
            ch_person_phone = ch_person_phone,
            ch_person_mobilenumber = ch_person_mobilenumber,
        )
        per.save()
        return redirect('client')
    return render(request,'tool/client.html')

def Delete(request,id):
    per=cl_Person.objects.filter(id=id)
    per.delete()
    context={
        'per':per,
    }
    return redirect('client')




def team(request):
    tem=cl_Team.objects.all()
    if request.method=="GET":
        q =request.GET.get('searchname')
        if q!=None:

             tem =cl_Team.objects.filter(ch_teamname__icontains=q)
    
    
    
    return render(request, 'tool/service.html',{ 'tem':tem})    


def TADD(request):
    if request.method == "POST":
        id=request.POST.get('id')
        ch_teamname=request.POST.get('ch_teamname')
        ch_teamstatus=request.POST.get('ch_teamstatus')
        ch_organization=request.POST.get('ch_organization')
        e_team_emailfield=request.POST.get('e_team_emailfield')
        i_team_phonenumber=request.POST.get('i_team_phonenumber')
        b_team_notification=request.POST.get('b_team_notification')
        ch_team_function=request.POST.get('ch_team_function')
        tem=cl_Team(
            id = id,
            ch_teamname = ch_teamname,
            ch_teamstatus = ch_teamstatus,
            ch_organization = ch_organization,
            e_team_emailfield = e_team_emailfield,
            i_team_phonenumber = i_team_phonenumber,
            b_team_notification = b_team_notification,
            ch_team_function = ch_team_function,
        )
        tem.save()

        return redirect('team')

    return render(request,'tool/service.html')

def TEdit(request):
    tem = cl_Team.objects.all()
    context={
        'tem':tem,
    }
    return render(request,'tool/service.html',context)

def TUpdate(request,id):
    if request.method == "POST":
        id=request.POST.get('id')
        ch_teamname=request.POST.get('ch_teamname')
        ch_teamstatus=request.POST.get('ch_teamstatus')
        ch_organization=request.POST.get('ch_organization')
        e_team_emailfield=request.POST.get('e_team_emailfield')
        i_team_phonenumber=request.POST.get('i_team_phonenumber')
        b_team_notification=request.POST.get('b_team_notification')
        ch_team_function=request.POST.get('ch_team_function')
        tem=cl_Team(
            id=id,
            ch_teamname=ch_teamname,
            ch_teamstatus = ch_teamstatus,
            ch_organization = ch_organization,
            e_team_emailfield = e_team_emailfield,
            i_team_phonenumber = i_team_phonenumber,
            b_team_notification = b_team_notification,
            ch_team_function = ch_team_function,
        )
        tem.save()
        return redirect('team')
    return render(request,'tool/service.html')

def TDelete(request,id):
    tem=cl_Team.objects.filter(id=id)
    tem.delete()
    context={
        'tem':tem,
    }
    return redirect('team')

# def add_show(request):
#     if request.method=='POST':
#         form = NeworganizationForm(request.POST)
#         if form.is_valid():
#             org = form.cleaned_data['cl_New_organization']
#             reg = cl_New_organization(cl_New_organization = org)
#             form.save()
#             reg.save()
#     else:

#         form = NeworganizationForm()
#         stud = cl_New_organization.objects.all()
#     context={'form':form}
    
#     return render(request, 'tool/neworganization.html', context,{'stu':'stud'})



# def add_show(request):
#     form = NeworganizationForm(request.POST)
#     template = loader.get_template('tool/neworganization.html')
#     context={'form':form}
    
#     return HttpResponse(template.render(context, request))


# def new_organization(request):
#     template = loader.get_template('tool/neworganization.html')
#     return HttpResponse(template.render({}, request))




def new_organization(request):
    form=NeworganizationForm()
    
    if request.method=='POST':
        form=NeworganizationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/neworganization.html', context)


# def user_request(request):
#     x= request.POST['ch_organization']
#     form = NeworganizationForm(ch_organization = x)
#     form.save()
#     return HttpResponseRedirect(reverse('add_show'))





def user_request(request):
    form=UserrequestForm()
    if request.method=='POST':
        form=UserrequestForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/userrequest.html',context)


def new_change(request):
    form=NewchangeForm()
    if request.method=='POST':
        form=NewchangeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/newchange.html',context)





def customer_contract(request):
    form=CustomercontractForm()
    if request.method=='POST':
        form=CustomercontractForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/scustomer_contract.html',context)    


def providercontract(request):
    form=ProvidercontractForm()
    if request.method=='POST':
        form=ProvidercontractForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/sprovidercontract.html',context)


def servicefamilies(request):
    form=ServicefamiliesForm()
    if request.method=='POST':
        form=ServicefamiliesForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/sservicefamily.html',context)


def sservice(request):
    form=ServiceForm()
    if request.method=='POST':
        form=ServiceForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/sservice.html',context)



def service_subcategory(request):
    form=ServicesubcategoryForm()
    if request.method=='POST':
        form=ServicesubcategoryForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/sservicecategory.html',context)



def sla(request):
    form=slaForm()
    if request.method=='POST':
        form=slaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/ssla.html',context)



def slt(request):
    form=sltForm()
    if request.method=='POST':
        form=sltForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/sslt.html',context)



def servicedelivery(request):
    form=DeliverymodelForm()
    if request.method=='POST':
        form=DeliverymodelForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/sdelivery.html',context)



def synchro_data_source(request):
    form=SyncrodataForm()
    if request.method=='POST':
        form=SyncrodataForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/sysconfisynchro.html',context)
    


def oauth_google(request):
    form=OauthgoogleForm()
    if request.method=='POST':
        form=OauthgoogleForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/authgoogle.html',context)


def oauth_mazuree(request):
    form=OauthmazureeForm()
    if request.method=='POST':
        form=OauthmazureeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/authmazure.html',context)


def ldapuser(request):
    form=LdapuserForm()
    if request.method=='POST':
        form=LdapuserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/ldapuser.html',context)


def externaluser(request):
    form=ExternaluserForm()
    if request.method=='POST':
        form=ExternaluserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/externaluser.html',context)

def itsmuser(request):
    form=ItsmuserForm()
    if request.method=='POST':
        form=ItsmuserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/itsmuser.html',context)

def slacknoti(request):
    form=SlacknotiForm()
    if request.method=='POST':
        form=SlacknotiForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Data Add Successfully")
    context={'form':form}
    return render(request, 'tool/slacknoti.html', context)

def micronoti(request):
    form=MicronotiForm()
    if request.method=='POST':
        form=MicronotiForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'Data Add Successfully')
    context={'form':form}
    return render(request, 'tool/micronoti.html', context)


def webhook(request):
    form=WebhookForm()
    if request.method=='POST':
        form=WebhookForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'Data Add Successfully')
    context={'form': form}
    return render(request,'tool/webhook.html', context)


def googlechat(request):
    form=GooglechatForm()
    if request.method=='POST':
        form=GooglechatForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'Data Add Successfully')
    context={'form':form}
    return render(request,'tool/googlechat.html',context)

def rocketchat(request):
    form=RocketchatForm()
    if request.method=='POST':
        form=RocketchatForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'Data Add Successfully')
    context={'form':form}
    return render(request,'tool/rocketchat.html',context)


def itsmwebhook(request):
    form=ItsmwebhookForm()
    if request.method=='POST':
        form=ItsmwebhookForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'Data Add Successfully')
    context={'form':form}
    return render(request,'tool/itsmwebhook.html',context)


