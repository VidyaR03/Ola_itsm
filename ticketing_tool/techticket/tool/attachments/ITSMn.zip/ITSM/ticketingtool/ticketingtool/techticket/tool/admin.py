from django.contrib import admin
# from .models import team, person, location, document, software


# admin.site.register(team)
# admin.site.register(person)
# admin.site.register(location)
# admin.site.register(document)
# admin.site.register(software)




# Register your models here.
